CREATE DATABASE canteen_db;
USE canteen_db;

CREATE TABLE Menu_Log (
    menu_id INT PRIMARY KEY,
    date DATE,
    dish_name VARCHAR(100),
    planned_servings INT
);

CREATE TABLE Consumption_Log (
    consumption_id INT PRIMARY KEY,
    date DATE,
    dish_name VARCHAR(100),
    actual_servings INT,
    leftover_quantity INT
);

CREATE TABLE Attendance_Log (
    attendance_id INT PRIMARY KEY,
    date DATE,
    total_present INT
);

CREATE TABLE Inventory_Usage (
    inventory_id INT PRIMARY KEY,
    date DATE,
    item_name VARCHAR(100),
    quantity_used FLOAT,
    cost FLOAT
);

CREATE TABLE Feedback_Records (
    feedback_id INT PRIMARY KEY,
    date DATE,
    dish_name VARCHAR(100),
    rating INT,
    comment TEXT
);
SET GLOBAL local_infile = 1;

SELECT COUNT(*) FROM Menu_Log;
SELECT COUNT(*) FROM Consumption_Log;
SELECT COUNT(*) FROM Attendance_Log;
SELECT COUNT(*) FROM Inventory_Usage;
SELECT COUNT(*) FROM Feedback_Records;

SELECT DISTINCT date FROM Menu_Log ORDER BY date DESC LIMIT 5;
SELECT DISTINCT dish_name FROM Menu_Log;

-- planned vs. actual servings per dish ---
SELECT 
    m.date,
    m.dish_name,
    m.planned_servings,
    c.actual_servings,
    (m.planned_servings - c.actual_servings) AS wastage
FROM 
    Menu_Log m
JOIN 
    Consumption_Log c 
ON 
    m.date = c.date AND m.dish_name = c.dish_name
ORDER BY 
    m.date DESC;
    
    
    
     -- "Daily Attendance vs. Total Food Consumption"
SELECT 
    a.date,
    MAX(a.total_present) AS total_present,
    SUM(c.actual_servings) AS total_food_consumed
FROM 
    Attendance_Log a
JOIN 
    Consumption_Log c 
ON 
    a.date = c.date
GROUP BY 
    a.date
ORDER BY 
    a.date DESC;



 -- "Top Rated Dishes (User Feedback)"
SELECT 
    dish_name,
    ROUND(AVG(rating), 2) AS avg_rating,
    COUNT(*) AS feedback_count
FROM 
    Feedback_Records
GROUP BY 
    dish_name
ORDER BY 
    avg_rating DESC
LIMIT 10;



-- "Dishes with Lowest Ratings"
SELECT 
    dish_name,
    ROUND(AVG(rating), 2) AS avg_rating,
    COUNT(*) AS feedback_count
FROM 
    Feedback_Records
GROUP BY 
    dish_name
HAVING 
    avg_rating < 3
ORDER BY 
    avg_rating ASC;



-- "Most Frequently Cooked Dishes"
SELECT 
    dish_name,
    COUNT(*) AS frequency
FROM 
    Menu_Log
GROUP BY 
    dish_name
ORDER BY 
    frequency DESC
LIMIT 10;


-- "Dishes Frequently Overproduced (More Leftovers)"
SELECT 
    m.dish_name,
    COUNT(*) AS overproduced_days
FROM 
    Menu_Log m
JOIN 
    Consumption_Log c 
ON 
    m.date = c.date AND m.dish_name = c.dish_name
WHERE 
    (m.planned_servings - c.actual_servings) > 20
GROUP BY 
    m.dish_name
ORDER BY 
    overproduced_days DESC;


-- "Daily Wastage Percentage"
SELECT 
    m.date,
    SUM(m.planned_servings) AS total_planned,
    SUM(c.actual_servings) AS total_consumed,
    ROUND((SUM(m.planned_servings - c.actual_servings) * 100.0) / SUM(m.planned_servings), 2) AS wastage_percentage
FROM 
    Menu_Log m
JOIN 
    Consumption_Log c 
ON 
    m.date = c.date AND m.dish_name = c.dish_name
GROUP BY 
    m.date
ORDER BY 
    m.date DESC;


-- "Inventory Item Usage (Most Used)"
SELECT 
    item_name,
    SUM(quantity_used) AS total_used
FROM 
    Inventory_Usage
GROUP BY 
    item_name
ORDER BY 
    total_used DESC
LIMIT 10;



-- " Inventory Cost Analysis"
SELECT 
    WEEK(date) AS week_num,
    YEAR(date) AS year_num,
    ROUND(SUM(cost), 2) AS weekly_cost
FROM 
    Inventory_Usage
GROUP BY 
    year_num, week_num
ORDER BY 
    year_num DESC, week_num DESC;



-- "Weekly Cost Trend"
SELECT 
    WEEK(date) AS week_num,
    YEAR(date) AS year_num,
    ROUND(SUM(cost), 2) AS weekly_cost
FROM 
    Inventory_Usage
GROUP BY 
    year_num, week_num
ORDER BY 
    year_num DESC, week_num DESC;


-- "Most Commented Dishes"
SELECT 
    dish_name,
    COUNT(comment) AS comment_count
FROM 
    Feedback_Records
WHERE 
    comment IS NOT NULL AND TRIM(comment) != ''
GROUP BY 
    dish_name
ORDER BY 
    comment_count DESC
LIMIT 10;



-- "Monthly Attendance Summary"
SELECT 
    MONTH(date) AS month,
    YEAR(date) AS year,
    SUM(total_present) AS total_attendance
FROM 
    Attendance_Log
GROUP BY 
    year, month
ORDER BY 
    year DESC, month DESC;



-- "Cost Efficiency: Cost Per Person Served (Daily)"
SELECT 
    a.date,
    MAX(a.total_present) AS total_present,
    ROUND(SUM(i.cost) / MAX(a.total_present), 2) AS cost_per_person
FROM 
    Attendance_Log a
JOIN 
    Inventory_Usage i ON a.date = i.date
GROUP BY 
    a.date
ORDER BY 
    a.date DESC;

